<?php

 echo anchor('main/showShowtimes','Show Showtimes') . "<br />";
 echo anchor('main/populate','Populate Database') . "<br />";
 echo anchor('main/delete','Delete Databse') . "<br />";  
 
 
?>

